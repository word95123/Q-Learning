import random
import copy
class ER:
    def __init__(self, max_len = 100):
        self.replay = []
        self.max_len = max_len
        self.current_game = []

    
    def store(self, state, action, reward, next_state):
        self.current_game.append((state, action, reward, next_state))
        if(reward != 0):
            for s, a, r, _s in self.current_game:
                self.replay.append((s, a, r, _s))
            while len(self.replay) > self.max_len:
                self.replay.pop(0)
            self.current_game = []
    
    def get_random_minibatch(self, size = 5):
        if len(self.replay) > size:
            copied = copy.deepcopy(self.replay)
            random.shuffle(copied)
            return copied[:size]
        else:
            return self.replay