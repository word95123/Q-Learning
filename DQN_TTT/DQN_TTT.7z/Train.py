from Game import TicTacToes
from build_net import Bot
import numpy as np

bot = Bot()
bot.train(1001)
