from keras.models import Sequential
from keras.layers import Dense, Activation
from keras.optimizers import rmsprop
from keras.optimizers import RMSprop, SGD
import numpy as np
from experience_replay import ER
from Game import TicTacToes
import random
import matplotlib.pyplot as plt

class Bot:
    def __init__(self, max_steps = 5):
        self.update_weight = 50
        self.memory_max_len = 100
        self.epsilon = 1.0
        self.ER = ER(self.memory_max_len)
        self.max_steps = max_steps
        self.ttt = TicTacToes()
        self.player = 'O'
        self.bot = 'X'
        self.learning_rate = 0.0001
        self.gamma = 0.95

        self.train_model = Sequential()
        self.train_model.add(Dense(units=36,input_dim=18, activation = 'relu'))
        self.train_model.add(Dense(units=18, activation = 'relu'))
        self.train_model.add(Dense(units=9, activation = 'linear'))
        self.train_model.compile(loss='mse', optimizer = RMSprop(lr = self.learning_rate), metrics=['accuracy'])

        self.frozen_model = Sequential()
        self.frozen_model.add(Dense(units=36,input_dim=18, activation = 'relu'))
        self.frozen_model.add(Dense(units=18, activation = 'relu'))
        self.frozen_model.add(Dense(units=9, activation = 'linear'))
        self.frozen_model.compile(loss='mse', optimizer = RMSprop(lr = self.learning_rate))
        
    def clip(self, x): #clip reward to rannge [1, -1]
        if (x > 1):
            return 1
        elif x < -1:
            return -1
        else:
            return x
    
    def frozen_update(self):
        weights = self.train_model.get_weights()
        target_weights = self.frozen_model.get_weights()
        for i in range(len(target_weights)):
            target_weights[i] = weights[i]
        self.frozen_model.set_weights(target_weights)

    def train(self, max_episodes):
        greedy = 0
        winner = 0
        lost = 0
        draw = 0
        total_step = 0
        show_result = []
        for episode in range(max_episodes):
            state, legal_moves = self.ttt.reset()
            print("trainining", episode)
            if(episode % self.update_weight == 0):
                print('save weight')
                self.frozen_update()
                self.train_model.save_weights('weights.h5', overwrite=True)
                #self.frozen_model.compile(loss='mse', optimizer ='rmsprop')

                
            
            for step in range(self.max_steps):           
                #prep input
                
                #print(len(np.array([[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]])))
                inp = np.array([state])
                preds = self.train_model.predict(inp)[0]
                #random variable
                a = random.random()
                if a < self.epsilon:
                    action = self.ttt.get_random_move()
                else:
                    greedy += 1
                    action = np.argmax(preds)
                
                self.epsilon = max(self.epsilon*0.995, 0.1)
                
                reward, done = self.ttt.drawMove(action, self.bot)
                if(done == 0):
                    if(episode < 50000):
                        action = self.ttt.get_random_move()
                    else:
                        reversed_state = self.ttt.get_bot_move()
                        inp = np.array([reversed_state])
                        _preds = self.train_model.predict(inp)[0]
                        action = np.argmax(_preds)
                        
                    if(action is not None):
                        reward, done = self.ttt.drawMove(action, self.player)
                
                if(done == 1):
                    winner += 1
                elif(done == 2):
                    lost += 1
                elif(done == 3):
                    draw += 1
                total_step += 1

                next_state = self.ttt.get_state()
                self.ER.store(state, preds, reward, next_state)
                replay = self.ER.get_random_minibatch(5)

                X = np.array(list(map(lambda x: x[0], replay)))
                y = []

                for s, a, r, _s in replay:
                    
                    if r == 0:
                        #evaluate_max = np.argmax(self.train_model.predict(np.array([_s])))
                        r = r + np.max(self.frozen_model.predict(np.array([_s]))) * self.gamma #DQN
                        #r = r + (self.frozen_model.predict(np.array([_s]))[0][evaluate_max]) * self.gamma #DDQN
                        
                    target = self.train_model.predict(np.array([s]))[0] 
                    target[np.argmax(a)] = self.clip(r)
                    
                    
                    y.append(target)

                y = np.array(y)

                state = next_state
                if len(X) > 0:
                    #self.train_model.train_on_batch(X, y)
                    
                    historys = self.train_model.fit(X, y, epochs=1, verbose=0)
                    #print(historys.history.keys())
                    show_result.append(historys.history['loss'])
                    #print('%.2f' % historys.history['acc'][0])
                    
                if(done != 0):
                    break
                
        
        plt.plot(show_result)        
        plt.show()       
        print('total_step',total_step)
        print('winner',winner)
        print('lost',lost)
        print('draw',draw)
        print('greedy',greedy)
        
        
        
        
    