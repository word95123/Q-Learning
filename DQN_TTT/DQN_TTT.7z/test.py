import numpy as np
a = -5
print(pow(a,2))